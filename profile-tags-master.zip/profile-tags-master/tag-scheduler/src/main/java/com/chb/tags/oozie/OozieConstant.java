package com.chb.tags.oozie;

public class OozieConstant {
    static String HDFSROOTPATH = "hdfs://chb3:8020";
    static String OOZIE_URL = "http://chb2:11000/oozie/";
    static String jobTracker = "chb2:8032";
}