package com.chb.tags.platform.entity;

public class Codes {
    public static final Integer SUCCESS = 0;
    public static final Integer ERROR_PARAM = 1;
    public static final Integer ERROR_UPLOAD = 2;
}
