package com.chb.tags.platform.service.impl;

import com.chb.tags.platform.entity.dto.ModelDto;
import com.chb.tags.platform.service.Engine;
import com.chb.tags.up.OozieParam;
import com.chb.tags.up.OozieUtils;
import org.springframework.stereotype.Service;

import java.util.Properties;

@Service
public class EngineImpl implements Engine {
    @Override
    public void startModel(ModelDto model) {
        // 设置动态的参数, 例如如何调度, 主类名, jar 的位置
        OozieParam param = new OozieParam(
                model.getId(),
                model.getMainClass(),
                model.getPath(),
                model.getArgs(),
                ModelDto.Schedule.formatTime(model.getSchedule().getStartTime()),
                ModelDto.Schedule.formatTime(model.getSchedule().getEndTime())
        );

        // 生成配置
        Properties properties = OozieUtils.genProperties(param);

        // 上传各种配置, workflow.xml, coordinator.xml
        OozieUtils.uploadConfig(model.getId());

        // 因为如果不保留一份 job.properties 的文件, 无法调试错误
        OozieUtils.store(model.getId(), properties);

        // 运行 Oozie 任务
        OozieUtils.start(properties);
    }

    @Override
    public void stopModel(ModelDto model) {

    }
}
