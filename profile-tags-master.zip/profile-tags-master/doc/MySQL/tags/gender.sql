



INSERT INTO `tbl_model` VALUES ('1', '318', 'MATCH','com.chb.tags.models.rule.GenderModel', 'hdfs://chb1:8020/apps/temp/jars/9f0d015b-8535-4538-8722-1d9a331069d1.jar', '4,2019-12-03 10:00:00,2029-12-03 10:00:00', '2019-12-03 11:11:54', '2019-12-03 11:11:54', '4', '--driver-memory 512m --executormemory 512m --num-executors 1 --executor-cores 1');
