#!/bin/bash
export host="chb1"
export db="tags_dat"
export user="root"
export pwd="123456"