package com.chb.tags.up;

public class CommonException extends RuntimeException {
}
