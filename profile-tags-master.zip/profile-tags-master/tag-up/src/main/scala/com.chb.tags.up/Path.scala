package com.chb.tags.up

case class Path(
                jars:String,
                modelBase:String)
