package com.chb.tags.up

case class Hadoop(
                   nameNode: String,
                   resourceManager: String
                 )
