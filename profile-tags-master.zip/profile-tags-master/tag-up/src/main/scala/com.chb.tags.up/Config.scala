package com.chb.tags.up

case class Config
(
  model: Model,
  hadoop: Hadoop,
  mysql: MySQL,
  oozie: Oozie
)
