package com.chb.tags.up

case class MySQL(
                  url: String,
                  driver: String,
                  tagTable: String,
                  modelTable: String
                )
