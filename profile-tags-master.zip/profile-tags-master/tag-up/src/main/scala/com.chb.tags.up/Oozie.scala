package com.chb.tags.up

case class Oozie(
                  url: String,
                  params: Map[String, String]
                )
