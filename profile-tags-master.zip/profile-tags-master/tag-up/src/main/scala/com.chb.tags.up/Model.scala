package com.chb.tags.up

case class Model
(
  user: String,
  app: String,
  path: Path
)
