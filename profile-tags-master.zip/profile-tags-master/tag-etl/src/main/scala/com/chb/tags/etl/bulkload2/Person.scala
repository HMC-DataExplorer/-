package com.chb.tags.etl.bulkload2

case class Person(id: Int, name: String, age: Int)
