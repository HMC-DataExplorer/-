import { render, staticRenderFns } from "./TaskPage.vue?vue&type=template&id=6a690885&scoped=true&"
import script from "./TaskPage.vue?vue&type=script&lang=js&"
export * from "./TaskPage.vue?vue&type=script&lang=js&"


/* normalize component */
import normalizer from "!../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  "6a690885",
  null
  
)

export default component.exports