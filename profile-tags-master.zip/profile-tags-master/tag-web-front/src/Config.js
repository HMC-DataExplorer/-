export default {
  baseApi: "http://localhost:8081/"
}